Lab 9 - Data Analysis and Visualization (D3.js)

Files
  task1_treemap.html            Course Enrollment Treemap
  task2_dendrogram.html         University Structure Dendrogram (click a department to collapse/expand)
  task3_flight_network.html     Flight Route Network (force-directed)
  task4_choropleth.html         World Population Choropleth
  task5_pakistan_points.html    Pakistan Cities Point Map
  task6_combined_map.html       Combined Spatial Encoding Map
  dataset/                      university.csv, flights.csv, population.csv, pakistan_cities.csv, world.geojson
  lib/d3.min.js                 D3 v7 (local copy, so pages work offline)

Run: open the folder in VS Code and use Live Server (pages load CSV/GeoJSON with fetch, so they will not work from file://).
Note: the datasets were not supplied with the manual, so sample data was created with the column names the manual specifies.
Replace the CSVs with your own versions if your instructor provides them (same file names/columns).
